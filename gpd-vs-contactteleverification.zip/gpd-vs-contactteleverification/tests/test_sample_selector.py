import logging
import unittest
from utilities.process_contact_tv.sample_selector import SampleSelector


class TestSampleSelector(unittest.TestCase):
    def test_selects_requested_count(self):
        records = [{"id": i} for i in range(10)]
        selected, remaining = SampleSelector(logging.getLogger(__name__)).select(records, 4)
        self.assertEqual(len(selected), 4)
        self.assertEqual(len(remaining), 6)
        self.assertEqual({r["id"] for r in selected} | {r["id"] for r in remaining}, set(range(10)))
