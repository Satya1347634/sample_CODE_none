import logging
import tempfile
import unittest
from utilities.process_contact_tv.vendor_response_processor import VendorResponseProcessor


class TestVendorResponseProcessor(unittest.TestCase):
    def test_reads_csv(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as file_obj:
            file_obj.write("id,called,verified\n1,yes,yes\n")
            path = file_obj.name
        records = VendorResponseProcessor(logging.getLogger(__name__)).process(path, tempfile.mkdtemp())
        self.assertEqual(records[0]["id"], "1")
