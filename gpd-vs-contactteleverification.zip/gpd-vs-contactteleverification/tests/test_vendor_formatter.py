import logging
import tempfile
import unittest
from utilities.process_contact_tv.vendor_formatter import VendorFormatter


class TestVendorFormatter(unittest.TestCase):
    def test_writes_csv(self):
        with tempfile.NamedTemporaryFile(suffix=".csv") as file_obj:
            VendorFormatter(logging.getLogger(__name__)).write_file(
                file_obj.name,
                [{"name": "A", "phone": "1"}],
                ["name", "phone"],
            )
            with open(file_obj.name, "r") as result:
                self.assertIn("name,phone", result.read())
