import logging
import unittest
from utilities.process_contact_tv.control_file_validator import ControlFileValidator


class TestControlFileValidator(unittest.TestCase):
    def setUp(self):
        self.logger = logging.getLogger(__name__)

    def test_defaults_are_valid(self):
        self.assertTrue(ControlFileValidator(None, self.logger, {}).validate())

    def test_invalid_sample_size(self):
        validator = ControlFileValidator(None, self.logger, {"sample_size": 0})
        self.assertFalse(validator.validate())

    def test_invalid_batch_type(self):
        validator = ControlFileValidator(None, self.logger, {"batch_type_id": 5})
        self.assertFalse(validator.validate())
