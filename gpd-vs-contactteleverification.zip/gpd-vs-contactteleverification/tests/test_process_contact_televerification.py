import logging
import tempfile
import unittest
from utilities.process_contact_tv.process_contact_televerification import ProcessContactTeleverification


class TestProcessContactTeleverification(unittest.TestCase):
    def test_read_csv(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as file_obj:
            file_obj.write("id,name\n1,A\n2,B\n")
            path = file_obj.name
        records = ProcessContactTeleverification.read_csv(path)
        self.assertEqual(len(records), 2)
