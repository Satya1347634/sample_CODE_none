# Changelog

## 0.1.0

Initial Contact Televerification utility structure based on the Email Verification Request application infrastructure.
