# -*- coding: utf-8 -*-
import argparse
import logging
import os
import sys

from configuration import configs
from mysql_connector_utils import MySQLdbm
from process_utils import set_pid_file, process_is_running
from utilities.process_contact_tv.executor import Executor

logger = logging.getLogger("user_utility")
EXIT_CODE_PROCESS_RUNNING = 2


def getArgs():
    parser = argparse.ArgumentParser(
        description="Run Contact Televerification userutility - Env - {}".format(configs.ENV)
    )
    parser.add_argument(
        "-f", "--force_run", action="store_true",
        help="Allow parallel run of another userutility"
    )
    parser.add_argument(
        "--contact-tv", action="store_true", dest="contact_tv_process",
        help="Process Contact Televerification batches"
    )
    parser.add_argument(
        "--send-only", action="store_true", dest="send_only",
        help="Process new Contact Televerification requests"
    )
    parser.add_argument(
        "--receive-only", action="store_true", dest="receive_only",
        help="Process returned Contact Televerification results"
    )
    return parser.parse_args()


class UserUtility:
    def __init__(self):
        self.args = getArgs()
        self.process_type = ""

    def start_contact_tv_process(self, ing_conn, ver_conn):
        executor = Executor(ing_conn, ver_conn, configs, logger, self.args)
        executor.execute()

    def execute(self):
        ing_conn = None
        ver_conn = None
        self.set_process_type()
        try:
            ing_conn = MySQLdbm(**configs.cia, logger=logger)
            ver_conn = MySQLdbm(**configs.ver, logger=logger)
            if self.process_type == "contact_tv":
                logger.info("Started contact_tv process")
                self.start_contact_tv_process(ing_conn, ver_conn)
                logger.info("Ended contact_tv process")
        except Exception:
            logger.exception("Exception in execute")
            raise
        finally:
            if ing_conn:
                ing_conn.close()
                logger.info("Closing connection to %s", configs.cia["host"])
            if ver_conn:
                ver_conn.close()
                logger.info("Closing connection to %s", configs.ver["host"])

    def set_process_type(self):
        if self.args.contact_tv_process:
            self.process_type = "contact_tv"


def main():
    is_not_running = False
    pid_path = configs.PID_PATH
    try:
        if process_is_running(pid_path):
            is_not_running = True
            logger.error("userutility process already running, exiting.")
            sys.exit(EXIT_CODE_PROCESS_RUNNING)

        pid_file = set_pid_file(pid_path)
        if not pid_file:
            is_not_running = True
            logger.error("userutility unable to create/update pid file, exiting.")
            sys.exit(EXIT_CODE_PROCESS_RUNNING)

        logger.info("No existing runs, starting userutility process")
        UserUtility().execute()
    except Exception as exc:
        logger.exception("Failure in main: %s", exc)
        raise
    finally:
        if not is_not_running:
            try:
                os.remove(pid_path)
                logger.info("Successfully removed pid file")
            except OSError:
                logger.info("Error while trying to remove pid file")


if __name__ == "__main__":
    main()
