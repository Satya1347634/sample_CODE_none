
import socket
from email.mime.multipart import *
from email.mime.text import *
from email.utils import formatdate
import smtplib
import logging
from configuration import configs
from email.mime.base import MIMEBase
from email import encoders


def send_email(configs, logger, receiver, subject, email_text, attachment):
    """
    Sends email
    :param receiver: Receiver email (it may be individual email or distribution list)
    :param filename: attachment filename with path
    :param subject: Subject of the email along with server name(based host name you can easily identify from which
    server your receiving the message)
    :param email_text: error message details
    :param logger: get logging details
    :return:
    """

    try:
        hostname = socket.gethostname()
        msg = MIMEMultipart()
        msg['From'] = configs.email['sender']
        msg['To'] = receiver
        # msg['CC'] = configs.email['send_cc']
        msg['Date'] = formatdate(localtime=True)
        msg['Subject'] = subject + ' ON ' + hostname
        body = email_text
        msg.attach(MIMEText(body, 'plain'))
        logger.info(msg.as_string())
        file = attachment
        if file:
            attachment = MIMEBase('application', 'octet-stream')
            attachment.set_payload(open(file, 'rb').read())
            encoders.encode_base64(attachment)
            attachment.add_header('Content-Disposition', 'attachment', filename=file)
            msg.attach(attachment)

        smtp = smtplib.SMTP(host=configs.email['smtp_ip'])
        smtp.sendmail(configs.email['sender'], receiver, msg.as_string())
        smtp.close()
    except Exception as e:
        logger.error(e)
