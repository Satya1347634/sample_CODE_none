import sys
import logging.config

sys.path.append("/netpx/conf/contactteleverification/target")

try:
    import config as configs
except ImportError:
    import local_config as configs
    print("couldn't locate contact televerification config directory! using local configs!")

logging.config.dictConfig(configs.logging_config)
