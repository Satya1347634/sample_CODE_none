# Contact Televerification Utility

This repository is a new utility based on the existing Email Verification Request infrastructure.

## Reused from EV

The following are intentionally reused/adapted from the EV repository:

- `mysql_connector_utils.py`
- `process_utils.py`
- `email_alert.py`
- `requirements.txt`
- `utilities/__init__.py`
- configuration and user-utility patterns

Email-specific processing is not copied into the TV process.

## TV defaults

- `batch_type_id`: 9 (`ContactTeleverification`)
- `externalVendor_id`: 9 (default Transdata)
- `sample_size`: 500

## Input

The utility expects a CSV request file and a matching JSON control file. Example:

```json
{
  "sample_size": 500,
  "batch_type_id": 9,
  "externalVendor_id": 9
}
```

## Processing

1. Validate control JSON.
2. Read the request CSV.
3. Validate/filter supported markets.
4. Select the configured sample.
5. Read `verServices.BatchType` and `verServices.ExternalVendor` configuration.
6. Generate the vendor request file.
7. Receive and parse the vendor response.
8. Apply TV score rules.
9. Generate output.

## Important integration points

The following are intentionally not guessed:

- exact Contact Televerification batch creation/update SQL
- actual Transdata response column names
- vendor transport implementation
- supported country/market list
- database target columns for TV score/status

Those must be confirmed from the TV database/vendor contract before production use.

## Local run

```bash
python3 user_utility.py --contact-tv
```

## Tests

```bash
python3 -m unittest discover -s tests
```

## Syntax check

```bash
python3 -m compileall .
```
