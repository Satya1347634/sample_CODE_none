import MySQLdb
from MySQLdb._exceptions import OperationalError, ProgrammingError
from time import sleep
from inspect import stack

QUERY_RETRY_INTERVAL_LIST = [60, 120, 180, 240, 300, 360]


class MySQLdbm:

    def __init__(self, host, user, password, database, charset, autocommit, logger, query_retry_sleep_period=None, max_retry_attempt=5):
        self.conn_kargs = {"host": host, "user": user, "password": password, "database": database, "charset": charset, "autocommit": autocommit}
        self.conn = None
        self.cur_kargs = None
        self.logger = logger

        self.max_retry_attempt = max_retry_attempt
        self.query_retry_sleep_period = QUERY_RETRY_INTERVAL_LIST if query_retry_sleep_period is None else query_retry_sleep_period

    def create_connection(self):
        try:
            if self.conn is None:
                self.conn = MySQLdb.Connection(**self.conn_kargs)
        except:
            self.logger.error(f"An error occurred in create connection method host - {self.conn_kargs.get('host', '')}")
            raise

    def cursor(self, **kargs):
        self.create_connection()
        try:
            if kargs.__len__() == 0:
                kargs = {"cursorclass": None}

            self.cur_kargs = kargs
            # NOTE(20220919 dhanasekarans): know from where the cursor is created
            s = stack()[1]
            self.logger.debug(f"created cursor - lineno - {s.lineno} - function - {s.function} - type - {self.cur_kargs.get('cursorclass')}")
            return Cursorm(self.conn, self.conn_kargs, self.cur_kargs, self.logger, self.query_retry_sleep_period, self.max_retry_attempt)
        except:
            self.logger.error(f"An error occurred in {self.__str__()} cursor method for args - {kargs}")
            raise

    def commit(self):
        if self.conn.open:
            self.conn.commit()

    def close(self):
        if self.conn:
            if self.conn.open:
                self.conn.close()

    def __repr__(self):
        return "open connection" if self.conn is not None else ""


class Cursorm:
    def __init__(self, conn, conn_kargs, cur_kargs, logger, query_retry_sleep_period, max_retry_attempt):
        self.conn = conn
        self.cur = None
        self.conn_kargs = conn_kargs
        self.cur_kargs = cur_kargs
        self.logger = logger
        self.rowcount = 0
        self.lastrowid = 0
        self.exception_count = 0
        self.cur_depth_count = 0
        self.max_retry_attempt = max_retry_attempt
        self.query_retry_sleep_period = QUERY_RETRY_INTERVAL_LIST if query_retry_sleep_period is None else query_retry_sleep_period
        self.query, self.args_, self.procedure_name = [None] * 3

    def create_connection(self):
        self.conn = MySQLdb.Connection(**self.conn_kargs)
        self.cur = None

    def initialise_cursor(self):
        self.cur = self.conn.cursor(**self.cur_kargs)

    def create_cursor(self):

        if self.conn is None:
            self.create_connection()
            self.cursor_check()
        elif self.conn.open == 1:
            self.cursor_check()
        elif self.conn.open == 0:
            self.create_connection()
            self.initialise_cursor()
            self.logger.debug("connection is closed so creating both connection and cursor")

    def cursor_check(self):
        if self.cur is None:
            self.initialise_cursor()
            self.logger.debug("cursor is none, creating a new cursor")
        elif self.cur.connection is None:
            self.initialise_cursor()
            self.logger.debug("connection is closed, creating a new cursor from new connection")
        elif self.cur.connection.open == 0:
            self.initialise_cursor()
            self.logger.debug("cursor is closed, creating a new cursor")

    def execute(self, query, args_=None, return_rows_affected=False):
        """Actual execution of the query happens here with the ability to retry the query"""
        self.create_cursor()
        try:
            retry_attempts = 0
            # NOTE(20211018 dhanasekarans): keep executing until we either be successful or raise if we hit the max limit
            while True:
                try:
                    if self.conn.open == 0:
                        self.logger.debug(f"connection is closed - conn - {self.conn.open}")
                        self.create_cursor()
                    # NOTE(20220930 dhanasekarans): storing this for future reconnects
                    self.query, self.args_ = query, args_

                    self.cur.execute(query, args_)
                    # INFO(20220916 dhanasekarans): we commit if it's an insert or update
                    if query.lower().find("insert") != -1 or query.lower().find("update") != -1:
                        if self.conn_kargs.get("autocommit"):
                            self.conn.commit()
                    self.rowcount = self.cur.rowcount
                    self.lastrowid = self.cur.lastrowid
                    return self.rowcount if return_rows_affected else None

                except OperationalError as oe:
                    self.handle_sql_exceptions(query, args_)
                    continue
                except ProgrammingError as pe:
                    self.handle_sql_exceptions(query, args_)
                    continue
                except Exception as e:
                    if retry_attempts == 0:
                        self.logger.exception(
                            f"An error occurred while executing query - \n {query} - with args {args_} - cur {self.cur} - conn - {self.conn}")

                    # NOTE(20211018 dhanasekarans): if we hit max retry limit rollback changes and raise
                    if retry_attempts > self.max_retry_attempt:
                        self.logger.warning(f"Maximum retries reached for query {query} with args {args_}")
                        self.conn.rollback()
                        raise
                    sleep(self.query_retry_sleep_period[retry_attempts])
                    retry_attempts += 1
                    self.logger.error(f"Retry attempt {retry_attempts} for error - {e} - query - {query} - args - {args_}")
        except Exception as e:
            self.logger.error(f"An error occurred in execute method error - {e} - query - {query} - args - {args_} - exception count - {self.exception_count} - retry count - {retry_attempts}")
            raise

    def callproc(self, procedure_name, args):
        retry_attempts = 0
        self.create_cursor()
        try:
            # NOTE(20211018 dhanasekarans): keep executing until we either be successful or raise if we hit the max limit
            while True:
                try:
                    if self.conn.open == 0:
                        self.logger.debug(f"connection is closed - conn - {self.conn.open}")
                        self.create_cursor()
                    # NOTE(20221205 dhanasekarans): this is to make sure we don't get command out of sync error
                    self.cur.execute("select 1")
                    _ = self.cur.fetchall()
                    # NOTE(20220930 dhanasekarans): storing this for future reconnects
                    self.procedure_name, self.args_ = procedure_name, args

                    self.cur.callproc(procedure_name, args)
                    return

                except OperationalError as oe:
                    self.handle_sql_exceptions(procedure_name, args)
                    continue
                except ProgrammingError as pe:
                    self.handle_sql_exceptions(procedure_name, args)
                    continue
                except Exception as e:
                    if retry_attempts == 0:
                        self.logger.exception(
                            f"An error occurred while executing procedure - \n {procedure_name} - with args {args} - cur {self.cur} - conn - {self.conn}")

                    # NOTE(20211018 dhanasekarans): if we hit max retry limit rollback changes and raise
                    if retry_attempts > self.max_retry_attempt:
                        self.logger.warning(f"Maximum retries reached for query {procedure_name} with args {args}")
                        self.conn.rollback()
                        raise
                    sleep(self.query_retry_sleep_period[retry_attempts])
                    retry_attempts += 1
                    self.logger.error(f"Retry attempt {retry_attempts} for error - {e} - query - {procedure_name} - args - {args}")
        except Exception as e:
            self.logger.error(
                f"An error occurred in execute method error - {e} - query - {procedure_name} - args - {args} - exception count - {self.exception_count} - retry count - {retry_attempts}")
            raise

    def executemany(self, query, args_=tuple(), return_rows_affected=False):
        """Actual execution of the query happens here with the ability to retry the query"""
        self.create_cursor()
        retry_attempts = 0
        try:
            # NOTE(20211018 dhanasekarans): keep executing until we either be successful or raise if we hit the max limit
            while True:
                try:
                    if self.conn.open == 0:
                        self.logger.debug(f"connection is closed - conn - {self.conn.open}")
                        self.create_cursor()
                    # NOTE(20220930 dhanasekarans): storing this for future reconnects
                    self.query, self.args_ = query, args_

                    self.cur.executemany(query, args_)
                    # INFO(20220916 dhanasekarans): we commit if it's an insert or update
                    if query.lower().find("insert") != -1 or query.lower().find("update") != -1:
                        if self.conn_kargs.get("autocommit"):
                            self.conn.commit()
                    self.rowcount = self.cur.rowcount
                    self.lastrowid = self.cur.lastrowid
                    return self.rowcount if return_rows_affected else None

                except OperationalError as oe:
                    self.handle_sql_exceptions(query, args_)
                    continue
                except ProgrammingError as pe:
                    self.handle_sql_exceptions(query, args_)
                    continue
                except Exception as e:
                    if retry_attempts == 0:
                        self.logger.exception(f"An error occurred while executing query - \n {query} - with args {args_} - cur {self.cur} - conn - {self.conn}")

                    # NOTE(20211018 dhanasekarans): if we hit max retry limit rollback changes and raise
                    if retry_attempts > self.max_retry_attempt:
                        self.logger.warning(f"Maximum retries reached for query {query} with args {args_}")
                        self.conn.rollback()
                        raise
                    sleep(self.query_retry_sleep_period[retry_attempts])
                    retry_attempts += 1
                    self.logger.error(f"Retry attempt {retry_attempts} for error - {e} - query - {query} - args - {args_}")
        except Exception as e:
            self.logger.error(f"An error occurred in execute method error - {e} - query - {query} - args - {args_} - exception count - {self.exception_count} - retry count - {retry_attempts}")
            raise

    def fetchmany(self, total_rows):
        try:
            return self.cur.fetchmany(total_rows)
        except Exception as e:
            # INFO(20220930 dhanasekarans): this will execute the query again, may introduce duplicate values or runs
            self.logger.error(f"Error in fetchone - {e}")
            self.execute(self.query, self.args_)
            return self.cur.fetchmany(total_rows)

    def fetchall(self):
        return self.cur.fetchall()

    def fetchone(self):
        try:
            return self.cur.fetchone()
        except Exception as e:
            # INFO(20220930 dhanasekarans): this will execute the query again, may introduce duplicate values or runs
            self.logger.error(f"Error in fetchone - {e}")
            self.execute(self.query, self.args_)
            return self.cur.fetchone()

    def close(self):
        try:
            if self.conn:
                self.conn.close()
        except Exception as e:
            self.logger.error(f"can't close the connection now - {e}")

    def __iter__(self):
        for row in self.cur:
            yield row

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if self.cur is not None:
                if self.cur.connection is not None:
                    if self.cur.connection.open == 1:
                        self.cur.close()
        except Exception as e:
            self.logger.exception(f"can't close the cursor now - {e} - query - {self.query}")

    def __repr__(self):
        return "open connection" if self.conn is not None else ""

    def handle_sql_exceptions(self, query, args_):
        if self.exception_count >= 5:
            raise
        self.exception_count += 1
        self.logger.exception(f"Error while executing - query - {query[:1000]} - args {args_} - cur {self.cur} - conn - {self.conn} - {self.conn.open}")
        self.create_connection()
        self.create_cursor()

    def handle_fetch_exception(self, function_name=None, *args):
        if function_name is None:
            return
        try:
            return function_name(*args)
        except Exception as e:
            # INFO(20220930 dhanasekarans): this will execute the query again, may introduce duplicate values or runs
            self.logger.error(f"Error in fetchone - {e}")
            self.execute(self.query, self.args_)
            return function_name(*args)
