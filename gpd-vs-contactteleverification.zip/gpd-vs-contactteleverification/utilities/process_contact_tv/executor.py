import json
import os
import re
import shutil
from copy import deepcopy

from utilities.process_contact_tv.control_file_validator import ControlFileValidator
from utilities.process_contact_tv.process_contact_televerification import ProcessContactTeleverification


class Executor:
    def __init__(self, ing_conn, ver_conn, configs, logger, command_line_args):
        self.ing_conn = ing_conn
        self.ver_conn = ver_conn
        self.configs = configs
        self.logger = logger
        self.command_line_args = command_line_args
        self.default_configs_json = deepcopy(configs.DEFAULT_CONTROL_FILE_JSON)

    def validate_json_file(self, json_file_name):
        path = os.path.join(self.configs.IN_FTP_LOCATION, json_file_name)
        with open(path, "r") as file_obj:
            content = file_obj.read()
        if not content.strip():
            return True, {}
        try:
            control = json.loads(content)
        except (TypeError, ValueError):
            self.logger.exception("Error loading %s", json_file_name)
            return False, {}
        validator = ControlFileValidator(self.configs, self.logger, control)
        return validator.validate(), control

    def add_default_configs_to_control_file(self, control, batch_file_name):
        merged = deepcopy(self.default_configs_json)
        merged.update(control or {})
        stem = os.path.splitext(batch_file_name)[0]
        json_name = stem + ".json"
        processing_csv = os.path.join(self.configs.IN_FTP_LOCATION, "processing", batch_file_name)
        processing_json = os.path.join(self.configs.IN_FTP_LOCATION, "processing", json_name)
        with open(processing_json, "w") as file_obj:
            json.dump(merged, file_obj, indent=2)
        shutil.move(os.path.join(self.configs.IN_FTP_LOCATION, batch_file_name), processing_csv)
        return batch_file_name, merged

    def process_batch_file(self, batch_file_name, control):
        batch_name, final_control = self.add_default_configs_to_control_file(control, batch_file_name)
        input_path = os.path.join(self.configs.IN_FTP_LOCATION, "processing", batch_name)
        vendor_path = os.path.join(self.configs.OUT_FTP_LOCATION, "vendor", batch_name)
        os.makedirs(os.path.dirname(vendor_path), exist_ok=True)
        processor = ProcessContactTeleverification(
            self.ing_conn, self.ver_conn, self.logger, self.configs, self.command_line_args
        )
        return processor.execute(input_path, final_control, vendor_file=vendor_path)

    def start_processing_new_batch_files(self):
        base = self.configs.IN_FTP_LOCATION
        for name in os.listdir(base):
            if not re.match(self.configs.SEARCH_STRING_CONTROL_FILE_NAME, name):
                continue
            control_path = os.path.join(base, name)
            if not os.path.isfile(control_path):
                continue
            batch_name = os.path.splitext(name)[0] + ".csv"
            batch_path = os.path.join(base, batch_name)
            if not os.path.isfile(batch_path):
                self.logger.error("Control file %s has no matching CSV", name)
                continue
            valid, control = self.validate_json_file(name)
            if not valid:
                self.logger.error("Invalid control file %s", name)
                continue
            self.process_batch_file(batch_name, control)

    def execute(self):
        if not getattr(self.command_line_args, "receive_only", False):
            self.start_processing_new_batch_files()
        else:
            self.logger.info("Receive-only mode selected; response processing requires configured vendor response location.")
