class ControlFileValidator:
    DEFAULT_SAMPLE_SIZE = 500
    DEFAULT_BATCH_TYPE_ID = 9
    DEFAULT_EXTERNAL_VENDOR_ID = 9

    def __init__(self, configs, logger, json_to_validate):
        self.configs = configs
        self.logger = logger
        self.json_to_validate = json_to_validate or {}
        self.errors = []

    @staticmethod
    def is_type_of(value, expected_type):
        return value is None or type(value) is expected_type

    @staticmethod
    def trim_string(value):
        return value.strip() if isinstance(value, str) else value

    def validate_sample_size(self):
        value = self.json_to_validate.get("sample_size", self.DEFAULT_SAMPLE_SIZE)
        if type(value) is not int or value <= 0:
            self.errors.append("sample_size must be a positive integer")
            return False
        return True

    def validate_batch_type_id(self):
        value = self.json_to_validate.get("batch_type_id", self.DEFAULT_BATCH_TYPE_ID)
        if type(value) is not int or value != self.DEFAULT_BATCH_TYPE_ID:
            self.errors.append("batch_type_id must be 9 for ContactTeleverification")
            return False
        return True

    def validate_external_vendor_id(self):
        value = self.json_to_validate.get("externalVendor_id", self.DEFAULT_EXTERNAL_VENDOR_ID)
        if type(value) is not int or value <= 0:
            self.errors.append("externalVendor_id must be a positive integer")
            return False
        return True

    def validate(self):
        if not isinstance(self.json_to_validate, dict):
            self.errors.append("Control file must contain a JSON object")
            return False
        checks = [
            self.validate_sample_size(),
            self.validate_batch_type_id(),
            self.validate_external_vendor_id(),
        ]
        if not all(checks):
            self.logger.error("TV control-file validation failed: %s", self.errors)
        return all(checks)

    def get_errors(self):
        return list(self.errors)
