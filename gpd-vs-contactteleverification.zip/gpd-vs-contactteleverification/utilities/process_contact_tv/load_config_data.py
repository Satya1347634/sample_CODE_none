from copy import deepcopy
import json
from os.path import join

from utilities.process_contact_tv.custom_exceptions import NoConfigFileFound


class LoadConfigData:
    def __init__(self, logger, configs, description):
        self.logger = logger
        self.configs = configs
        self.description = description
        self.batch_file_name = None
        self.default_configs_json = deepcopy(configs.DEFAULT_CONTROL_FILE_JSON)

    def load_configs_file(self, config_file_name):
        path = join(self.configs.IN_FTP_LOCATION, "processing", config_file_name)
        with open(path, "r") as file_obj:
            content = file_obj.read()
        if not content.strip():
            return deepcopy(self.default_configs_json)
        loaded = json.loads(content)
        if not isinstance(loaded, dict):
            raise ValueError("Control file must contain a JSON object")
        result = deepcopy(self.default_configs_json)
        result.update(loaded)
        return result

    def get_config_data(self):
        if not self.description:
            raise NoConfigFileFound("No file description was supplied")
        stem = self.description.split("-")[0].strip().split(".")[0]
        if not stem:
            raise NoConfigFileFound("Unable to determine control-file name")
        self.batch_file_name = stem + ".csv"
        return self.load_configs_file(stem + ".json"), self.batch_file_name
