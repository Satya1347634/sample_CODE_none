class TVResultUpdater:
    VERIFIED_SCORE = 100
    NOT_VERIFIED_SCORE = 0

    def __init__(self, logger):
        self.logger = logger

    @staticmethod
    def truthy(value):
        return str(value).strip().lower() in {"1", "true", "yes", "y", "verified", "called"}

    @staticmethod
    def average(scores):
        return sum(scores) / len(scores) if scores else 0

    def calculate_scores(self, all_records, response_records, record_key, called_field, verified_field):
        response_by_key = {
            str(row.get(record_key)): row
            for row in response_records
            if row.get(record_key) is not None
        }
        called_scores = []
        for row in response_records:
            if self.truthy(row.get(called_field)):
                called_scores.append(
                    self.VERIFIED_SCORE if self.truthy(row.get(verified_field)) else self.NOT_VERIFIED_SCORE
                )
        average_score = self.average(called_scores)
        output = []
        for original in all_records:
            result = dict(original)
            vendor_row = response_by_key.get(str(original.get(record_key)))
            if vendor_row is None or not self.truthy(vendor_row.get(called_field)):
                result["tv_score"] = average_score
                result["tv_status"] = "NOT_CALLED"
            elif self.truthy(vendor_row.get(verified_field)):
                result["tv_score"] = 100
                result["tv_status"] = "VERIFIED"
            else:
                result["tv_score"] = 0
                result["tv_status"] = "UNABLE_TO_VERIFY"
            output.append(result)
        return output
