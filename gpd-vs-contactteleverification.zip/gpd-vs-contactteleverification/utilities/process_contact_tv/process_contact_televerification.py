import csv
import os

from utilities.process_contact_tv.control_file_validator import ControlFileValidator
from utilities.process_contact_tv.sample_selector import SampleSelector
from utilities.process_contact_tv.vendor_config import VendorConfig
from utilities.process_contact_tv.vendor_config_parser import VendorConfigParser
from utilities.process_contact_tv.vendor_formatter import VendorFormatter
from utilities.process_contact_tv.vendor_response_processor import VendorResponseProcessor
from utilities.process_contact_tv.tv_result_updater import TVResultUpdater
from utilities.process_contact_tv.output_file_generator import OutputFileGenerator


class ProcessContactTeleverification:
    BATCH_TYPE_ID = 9
    DEFAULT_VENDOR_ID = 9
    DEFAULT_SAMPLE_SIZE = 500

    def __init__(self, ing_conn, ver_conn, logger, configs, command_line_args=None):
        self.ing_conn = ing_conn
        self.ver_conn = ver_conn
        self.logger = logger
        self.configs = configs
        self.command_line_args = command_line_args
        self.sample_selector = SampleSelector(logger)
        self.vendor_config = VendorConfig(ver_conn, logger)
        self.vendor_formatter = VendorFormatter(logger)
        self.response_processor = VendorResponseProcessor(logger)
        self.result_updater = TVResultUpdater(logger)
        self.output_generator = OutputFileGenerator(logger)

    @staticmethod
    def read_csv(input_file, delimiter=","):
        with open(input_file, "r", newline="", encoding="utf-8-sig") as file_obj:
            return list(csv.DictReader(file_obj, delimiter=delimiter))

    def validate_markets(self, records):
        # Market rules are intentionally isolated here. The supported-country
        # list and unsupported-market scoring rule must come from the business owner.
        return records, []

    def validate_control(self, control):
        validator = ControlFileValidator(self.configs, self.logger, control)
        if not validator.validate():
            raise ValueError("Invalid control file: %s" % validator.get_errors())

    def prepare_vendor_request(self, selected_records, vendor_config, output_file, delimiter=","):
        batch_type = VendorConfigParser.parse_batch_type(vendor_config["batch_type"])
        vendor = VendorConfigParser.parse_vendor(vendor_config["vendor"])
        self.vendor_formatter.write_file(
            output_file,
            selected_records,
            batch_type["output_fields"],
            delimiter=delimiter,
        )
        return batch_type, vendor

    def execute(self, input_file, control_file, vendor_file=None):
        self.logger.info("Contact Televerification started for %s", input_file)
        self.validate_control(control_file)
        sample_size = control_file.get("sample_size", self.DEFAULT_SAMPLE_SIZE)
        vendor_id = control_file.get("externalVendor_id", self.DEFAULT_VENDOR_ID)
        batch_type_id = control_file.get("batch_type_id", self.BATCH_TYPE_ID)
        delimiter = control_file.get("field_delimiter", ",")

        records = self.read_csv(input_file, delimiter)
        eligible_records, unsupported_records = self.validate_markets(records)
        selected_records, not_selected_records = self.sample_selector.select(eligible_records, sample_size)
        config = self.vendor_config.load(batch_type_id, vendor_id)

        batch_type = VendorConfigParser.parse_batch_type(config["batch_type"])
        vendor = VendorConfigParser.parse_vendor(config["vendor"])

        result = {
            "input_records": records,
            "eligible_records": eligible_records,
            "unsupported_records": unsupported_records,
            "selected_records": selected_records,
            "not_selected_records": not_selected_records,
            "batch_type": batch_type,
            "vendor": vendor,
            "vendor_file": None,
        }

        if vendor_file:
            self.vendor_formatter.write_file(
                vendor_file,
                selected_records,
                batch_type["output_fields"],
                delimiter=delimiter,
            )
            result["vendor_file"] = vendor_file

        self.logger.info("Prepared %s records for vendor %s", len(selected_records), vendor["name"])
        return result

    def process_response(self, response_file, extract_directory, all_records, record_key, called_field, verified_field):
        response_records = self.response_processor.process(response_file, extract_directory)
        return self.result_updater.calculate_scores(
            all_records,
            response_records,
            record_key,
            called_field,
            verified_field,
        )
