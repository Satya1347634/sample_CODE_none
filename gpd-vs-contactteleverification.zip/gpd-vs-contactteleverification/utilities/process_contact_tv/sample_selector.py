import random


class SampleSelector:
    def __init__(self, logger):
        self.logger = logger

    def select(self, records, sample_size):
        if sample_size >= len(records):
            return list(records), []
        indexes = set(random.sample(range(len(records)), sample_size))
        selected = [record for i, record in enumerate(records) if i in indexes]
        not_selected = [record for i, record in enumerate(records) if i not in indexes]
        self.logger.info("Selected %s of %s records", len(selected), len(records))
        return selected, not_selected
