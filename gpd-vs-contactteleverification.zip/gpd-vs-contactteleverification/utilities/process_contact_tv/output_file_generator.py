import csv
import os


class OutputFileGenerator:
    def __init__(self, logger):
        self.logger = logger

    def generate(self, output_file, records, headers=None):
        if headers is None:
            headers = list(records[0].keys()) if records else []
        parent = os.path.dirname(output_file)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(output_file, "w", newline="", encoding="utf-8") as file_obj:
            writer = csv.DictWriter(file_obj, fieldnames=headers, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(records)
        self.logger.info("Generated TV output file %s", output_file)
        return output_file
