import csv
import os
import zipfile


class VendorResponseProcessor:
    def __init__(self, logger):
        self.logger = logger

    def extract_response(self, response_file, extract_directory):
        if not zipfile.is_zipfile(response_file):
            return response_file
        os.makedirs(extract_directory, exist_ok=True)
        with zipfile.ZipFile(response_file) as archive:
            archive.extractall(extract_directory)
        csv_files = []
        for root, _, names in os.walk(extract_directory):
            csv_files.extend(os.path.join(root, name) for name in names if name.lower().endswith(".csv"))
        if not csv_files:
            raise ValueError("No CSV response file found in vendor archive")
        return csv_files[0]

    def read_csv(self, file_path, delimiter=","):
        with open(file_path, "r", newline="", encoding="utf-8-sig") as file_obj:
            return list(csv.DictReader(file_obj, delimiter=delimiter))

    def process(self, response_file, extract_directory, delimiter=","):
        csv_file = self.extract_response(response_file, extract_directory)
        records = self.read_csv(csv_file, delimiter)
        self.logger.info("Read %s vendor response records", len(records))
        return records
