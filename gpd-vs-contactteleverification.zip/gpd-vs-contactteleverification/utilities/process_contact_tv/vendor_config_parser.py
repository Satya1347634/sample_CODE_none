import json


class VendorConfigParser:
    @staticmethod
    def parse_value(value):
        if value is None:
            return []
        if isinstance(value, (list, tuple, dict)):
            return value
        if isinstance(value, str):
            text = value.strip()
            if not text:
                return []
            try:
                return json.loads(text)
            except (TypeError, ValueError):
                return [part.strip() for part in text.split(",") if part.strip()]
        return value

    @classmethod
    def parse_batch_type(cls, value):
        return {
            "batch_type_id": value["batch_type_id"],
            "name": value["name"],
            "output_fields": cls.parse_value(value["output_field_list"]),
        }

    @classmethod
    def parse_vendor(cls, value):
        return {
            "external_vendor_id": value["external_vendor_id"],
            "name": value["name"],
            "response_fields": cls.parse_value(value["table_definition"]),
        }
