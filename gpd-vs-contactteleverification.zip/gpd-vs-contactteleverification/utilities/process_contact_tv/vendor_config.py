from utilities.process_contact_tv.custom_exceptions import VendorConfigurationError


class VendorConfig:
    def __init__(self, ver_conn, logger):
        self.ver_conn = ver_conn
        self.logger = logger

    def get_batch_type(self, batch_type_id=9):
        query = """
            SELECT batchType_id, name, outputFieldList
            FROM verServices.BatchType
            WHERE batchType_id = %s
        """
        with self.ver_conn.cursor() as cur:
            cur.execute(query, (batch_type_id,))
            row = cur.fetchone()
        if not row:
            raise VendorConfigurationError("No BatchType found for %s" % batch_type_id)
        return {"batch_type_id": row[0], "name": row[1], "output_field_list": row[2]}

    def get_external_vendor(self, external_vendor_id=9):
        query = """
            SELECT externalVendor_id, name, tableDefinition
            FROM verServices.ExternalVendor
            WHERE externalVendor_id = %s
        """
        with self.ver_conn.cursor() as cur:
            cur.execute(query, (external_vendor_id,))
            row = cur.fetchone()
        if not row:
            raise VendorConfigurationError("No ExternalVendor found for %s" % external_vendor_id)
        return {"external_vendor_id": row[0], "name": row[1], "table_definition": row[2]}

    def load(self, batch_type_id=9, external_vendor_id=9):
        return {
            "batch_type": self.get_batch_type(batch_type_id),
            "vendor": self.get_external_vendor(external_vendor_id),
        }
