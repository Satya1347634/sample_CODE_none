class NoConfigFileFound(Exception):
    pass


class InvalidControlFile(Exception):
    pass


class VendorConfigurationError(Exception):
    pass


class VendorResponseError(Exception):
    pass


class TeleverificationProcessingError(Exception):
    pass
