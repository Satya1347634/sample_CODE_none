import csv


class VendorFormatter:
    def __init__(self, logger):
        self.logger = logger

    @staticmethod
    def field_name(field):
        if isinstance(field, str):
            return field
        if isinstance(field, dict):
            return field.get("name") or field.get("fieldName") or field.get("column")
        return None

    def format_records(self, records, output_fields):
        fields = [self.field_name(field) for field in output_fields]
        fields = [field for field in fields if field]
        if not fields:
            raise ValueError("No vendor output fields were configured")
        return fields, [[record.get(field, "") for field in fields] for record in records]

    def write_file(self, file_path, records, output_fields, delimiter=","):
        headers, rows = self.format_records(records, output_fields)
        with open(file_path, "w", newline="", encoding="utf-8") as file_obj:
            writer = csv.writer(file_obj, delimiter=delimiter)
            writer.writerow(headers)
            writer.writerows(rows)
        self.logger.info("Created vendor request file %s", file_path)
        return file_path
