# -*- coding: utf-8 -*-
"""
process_utils.py
Source: From GCA, to check the existing predict email process is running or not.

    :author: Marshel Helsper <helsperm@dnb.com>
    :created: 7 October 2020
    :copyright: (c) 2020 Dun & Bradstreet Inc.

"""

import contextlib
import errno
import os


class WindowsPidFileHandler(object):
    def close(self):
        pass


def process_is_running(pid_path):
    if os.name == "nt":
        # NOTE(helsperm): The code below could accidentally kill processes, and
        # Windows (NT) should only be in use here for development (engineers'
        # laptops), never in production (which will be Linux). So always assume
        # that the process is not, in fact, running. It's up to the
        # local_config.py definition for the pid file.

        # NOTE(xies):it's a best effort file delete.
        try:
            os.remove(pid_path)
        except:
            pass
        return False

    try:
        with open(pid_path, "r") as f:
            running_pid = f.readline().strip()

        if len(running_pid) == 0:
            # NOTE(helsperm): Pid file was created, but the script ended before
            # the pid could be written.
            os.remove(pid_path)
            return False

        running_pid = int(running_pid)
        if running_pid == 0:
            # NOTE(helsperm): Pid 0 is special as it represents _all_
            # processes, so obviously it's running.
            return True

        os.kill(running_pid, 0)
    except IOError as err:
        if err.errno == errno.ENOENT:
            # NOTE(helsperm): No pid file means no process.
            return False
        else:
            raise
    except OSError as err:
        if err.errno == errno.ESRCH:
            # NOTE(helsperm): No process with that pid found
            os.remove(pid_path)
            return False
        elif err.errno == errno.EPERM:
            # NOTE(helsperm): There's a process denying us, which means it
            # exists and is running.
            return True
        else:
            # NOTE(helsperm): A different error we need to raise
            raise

    # NOTE(helsperm): If we get here, the kill went through and the process
    # exists.
    return True


def set_pid_file(pid_path):
    result = None
    if os.name == "nt":
        # NOTE(helsperm): The code below could accidentally kill processes, and
        # Windows (NT) should only be in use here for development (engineers'
        # laptops), never in production (which will be Linux).
        result = WindowsPidFileHandler()
        return result

    try:
        # NOTE(helsperm): We're using this os-level file open function rather
        # than the Python built-in because we want to double-check that we
        # really are the only process running. We ask the OS to create
        # (O_CREAT) the file, only if one does not exist (exclusive, O_EXCL).
        # If we throw an exception here of errno.EEXIST then another process
        # created the pid before us.
        fd = os.open(pid_path, os.O_CREAT|os.O_EXCL|os.O_WRONLY)

        # NOTE(helsperm): We still hand over a Python file object once we're passed this
        result = os.fdopen(fd, "w")
        result.write("{}".format(os.getpid()))
        result.flush()
        # NOTE(20220725 dhanasekarans): we earlier closed the fd like os.close(fd) which raised IOError: [Errno 9] Bad file descriptor because
        # we are using os to close instead of the file object itself
        result.close()
    except OSError as err:
        if err.errno != errno.EEXIST:
            # NOTE(helsperm): If the problem is anything else, we raise.
            raise

    return result
